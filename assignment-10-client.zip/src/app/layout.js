import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ToastContainer } from "react-toastify";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});


export const metadata = {
  title: 'BloodBridge',
  description: 'A modern blood donation platform',
  icons: {
    icon: '/blood-logo.jpg',
  },
};

export default function RootLayout({ children }) {
  return (
    <html
      lang="en"
      data-theme="light"
      className={`${geistSans.variable} ${geistMono.variable} h-full light antialiased`}
    >
      <body className="min-h-full flex flex-col">

        <Navbar />
        {children}
        <Footer />
        <ToastContainer />
        </body>
    </html>
  );
}
